Locales['en'] = {
  ['korjaus'] = 'Paina ~o~ ~INPUT_CONTEXT~ ~w~ korjataksesi ajoneuvo',
  ['korjaus_mutta_maksu'] = 'Paina ~o~ ~INPUT_CONTEXT~ ~w~ korjataksesi ajoneuvo hintaan ~g~$%s~s~',

  ['korjaus_kusahti'] = '~r~ Sinulla ei ole riittävästi käteistä!',
  ['korjaus_mitavittua'] = 'Ajoneuvosi ei tarvitse korjausta.',

  ['korjaus_onnistui'] = '~o~ Ajoneuvosi on korjattu',
  ['korjaus_onnistui_mutta_maksu'] = '~o~ Ajoneuvosi on korjattu hintaan ~g~$%s~s~',

  ['blippi_korjauspisteeseen'] = 'Robomeksu',
}
