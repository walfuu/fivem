ESX = nil

TriggerEvent('walfu:getSharedWALFUObject', function(obj) ESX = obj end)

ESX.RegisterServerCallback('moioleneltsu:onkomasseis', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)

	if Config.Maksaakokorjaus then
		if xPlayer.getMoney() >= Config.Paljonko then
			xPlayer.removeMoney(Config.Paljonko)
			cb(true)
		else
			cb(false)
		end
	else
		cb(true)
	end
end)