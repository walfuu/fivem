Config = {}

Config.Locale = 'en'

Config.Maksaakokorjaus = true
Config.Paljonko = 500

Config.Korjaakokoajoneuvo = false -- Muista jos Config.Realistinenajoneuvonrikkoutuminen on "true" niin tämän kannattaapi olla "false"

Config.Realistinenajoneuvonrikkoutuminen  = false -- Laita tämä "true" jos käytät resurssia RealisticVehicleFailure
Config.Moottorinkesto = 700.0 -- Suositus on 700.0 ( mitä pienempi sitä vähemmän korjauksesta hyötyä! )
Config.Bensatankinkesto = 700.0 -- Älä mielellään muokkaa tätä

Config.Kloppisijainnit = {
	vector3(-212.447, -1325.749, 29.840) 
}